static const char* colorname[] = {
    // 8 normal colors
    "#bcc0cc", // Surface1
    "#d20f39", // Red
    "#40a02b", // Green
    "#df8e1d", // Yellow
    "#1e66f5", // Blue
    "#ea76cb", // Pink
    "#179299", // Teal
    "#5c5f77", // Subtext1

    // 8 bright colors
    "#acb0be", // Surface2
    "#d20f39", // Red
    "#40a02b", // Green
    "#df8e1d", // Yellow
    "#1e66f5", // Blue
    "#ea76cb", // Pink
    "#179299", // Teal
    "#ccd0da", // Subtext0

    [255] = 0,

    // default foreground colour
    "#4c4f69", // Text
    "#4c4f69", // Text
    "#4c4f69", // Text

    // default background colour
    "#eff1f5", // Base
};
