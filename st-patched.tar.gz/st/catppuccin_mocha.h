static const char* colorname[] = {
    // 8 normal colors
    "#45475a", // Surface1
    "#f38ba8", // Red
    "#a6e3a1", // Green
    "#f9e2af", // Yellow
    "#89b4fa", // Blue
    "#f5c2e7", // Pink
    "#94e2d5", // Teal
    "#bac2de", // Subtext1

    // 8 bright colors
    "#585b70", // Surface2
    "#f38ba8", // Red
    "#a6e3a1", // Green
    "#f9e2af", // Yellow
    "#89b4fa", // Blue
    "#f5c2e7", // Pink
    "#94e2d5", // Teal
    "#a6adc8", // Subtext0

    [255] = 0,

    // default foreground colour
    "#cdd6f4", // Text
    "#cdd6f4", // Text
    "#cdd6f4", // Text

    // default background colour
    "#1e1e2e", // Base
};
